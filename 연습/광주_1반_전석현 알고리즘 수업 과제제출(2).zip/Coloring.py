
import sys
sys.stdin = open('Coloring input.txt', 'r')
tc = int(input())
for i in range(0, tc):
    reds = []
    blues = []
    cnt = 0
    n = int(input())
    for j in range(n):
        tmp = []
        info = list(map(int, input().split()))
        for k in range(info[0], info[2]+1):
            for l in range(info[1], info[3]+1):
                tmp.append((k, l))
        if info[4] == 1:
            reds = reds + tmp
        else:
            blues = blues + tmp
    for red in reds:
        if red in blues:
            cnt += 1
    print('#%d'%(i+1), cnt)
