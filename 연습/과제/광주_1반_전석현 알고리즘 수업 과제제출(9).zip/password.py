class Node:
    def __init__(self, d=0, p=None, n=None):
        self.data = d
        self.prev = p
        self.next = n
        
class LinkedList:
    def __init__(self):
        self.head = Node('Head')
        self.head.next = self.head
        self.size = 0
        
    def insert(self, idx, data):
        new_node = Node(data)
        cur = self.head
        for i in range(idx):
            cur = cur.next
        if self.size==0:
            new_node.next = new_node
        else:
            new_node.next = cur.next
        cur.next = new_node
        new_node.prev = cur
        new_node.next.prev = new_node
        self.size += 1
        
    def findPW(self, M, K):
        cur = self.head
        for k in range(K):
            for i in range(M):
                cur = cur.next
            new_node = Node(cur.data+cur.next.data)
            new_node.next = cur.next
            cur.next = new_node
            new_node.next.prev = new_node
            new_node.prev = cur
            self.size += 1
        return
    
    def ans(self):
        ans = []
        cur = self.head.next
        for i in range(min(10,self.size)):
            cur = cur.prev
            ans.append(str(cur.data))
        return ans

for _ in range(int(input())):
    N,M,K = map(int,input().split())
    arr = list(map(int,input().split()))
    mylist = LinkedList()
    for i in range(N):
        mylist.insert(i,arr[i])
    mylist.findPW(M,K)
    print(f'#{_+1} {" ".join(mylist.ans())}')